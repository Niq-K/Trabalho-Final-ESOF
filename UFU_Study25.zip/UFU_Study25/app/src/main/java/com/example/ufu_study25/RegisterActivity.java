package com.example.ufu_study25;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    private EditText regEmail, regPass;
    private Button regbtn;
    private TextView regQn;
    private Toolbar toolbar;
    private DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_register);

        toolbar = findViewById(R.id.registerToolBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Registrar");

        regEmail = findViewById(R.id.registerEmail);
        regPass = findViewById(R.id.registerSenha);
        regbtn = findViewById(R.id.registerButton);
        regQn = findViewById(R.id.registerPageQuestion);
        DB = new DBHelper(this);

        regQn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        regbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = regEmail.getText().toString().trim();
                String pass = regPass.getText().toString().trim();

                if(TextUtils.isEmpty(user) || TextUtils.isEmpty(pass)){
                    Toast.makeText(RegisterActivity.this, "Todos os campos precisam ser preenchidos corretamente.",Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkUser = DB.checkUserPass(user, pass);
                    if(checkUser==false){
                        Boolean insert = DB.insertData(user,pass);
                        if(insert==true){
                            Toast.makeText(RegisterActivity.this, "Sucesso no Cadastro", Toast.LENGTH_SHORT).show();
                            Intent intent= new Intent(getApplicationContext(),HomeActivity.class);
                            intent.putExtra(user, user);
                            startActivity(intent);
                        } else {
                            Toast.makeText(RegisterActivity.this, "Falha no Cadastro", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(RegisterActivity.this, "Falha no Cadastro", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}