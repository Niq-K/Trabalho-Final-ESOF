package com.example.ufu_study25;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {

    protected ImageButton id_btn, calendar_btn, grades_btn, food_btn, intercampi_btn, exit_btn;
    protected Bundle extra;
    protected String user;
    protected TextView name,userID, mat1, mat2, mat3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        extra = getIntent().getExtras();

        user = extra.getString("user");

        id_btn = findViewById(R.id.id_icon);
        calendar_btn = findViewById(R.id.calendar_icon);
        grades_btn = findViewById(R.id.grades_icon);
        food_btn = findViewById(R.id.food_icon);
        intercampi_btn = findViewById(R.id.intercampi_icon);
        exit_btn = findViewById(R.id.exit_icon);
        name = findViewById(R.id.nameView);
        userID = findViewById(R.id.idView);
        mat1 = findViewById(R.id.materia1View);
        mat2 = findViewById(R.id.materia2View);
        mat3 = findViewById(R.id.materia3View);

        if(user.isEmpty()){

        }
        else {
            attViewName();
        }

        id_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        calendar_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        grades_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        food_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent h = new Intent(getApplicationContext(), FoodActivity.class);
            }
        });

        intercampi_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), IntercampiActivity.class);
                startActivity(i);
            }
        });

        exit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(i);
            }
        });




    }

    private void attViewName(){
        name.setText("Olá, "+ user);
    }
}