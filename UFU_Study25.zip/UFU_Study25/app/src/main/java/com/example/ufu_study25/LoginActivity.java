package com.example.ufu_study25;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    protected Toolbar toolbar;
    protected EditText username, password;
    protected Button loginBtn;
    protected DBHelper DB;
    protected TextView loginQn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);

        toolbar = findViewById(R.id.loginToolBar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Login");

        username = findViewById(R.id.loginEmail);
        password = findViewById(R.id.loginSenha);
        loginBtn = findViewById(R.id.loginButton);
        loginQn = findViewById(R.id.loginPageQuestion);
        DB = new DBHelper(this);

        loginQn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString().trim();
                String pass = password.getText().toString().trim();

                if(TextUtils.isEmpty(user) || TextUtils.isEmpty(pass)){
                    Toast.makeText(LoginActivity.this, "Todos os campos precisam ser preenchidos corretamente.",Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkUserPass = DB.checkUserPass(user, pass);
                    if(checkUserPass==true){
                        Toast.makeText(LoginActivity.this, "Sucesso no Login", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(),HomeActivity.class);
                        intent.putExtra("user", user);
                        startActivity(intent);
                    }
                    else{
                        Toast.makeText(LoginActivity.this, "Falha no Login", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}